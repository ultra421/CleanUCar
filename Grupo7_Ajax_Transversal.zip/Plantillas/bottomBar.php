<div id = "bottomBar">
 <div>

 </div>
</div>