<div id = "topBarMobile">
        <img id = "logo" src = "../../Imagenes/stucom_logo.png">
        <div id = "botonesLogin">
            <?php printInfo($log,$nombre,$pass) ?> <!-- Print info del usuario/boton login -->
        </div>
        <div id = "settings">
            <a href = "../../Paginas/Settings/Settings.php">
                <img src = "../../Imagenes/barras.png">
            </a>
        </div>
    </div>