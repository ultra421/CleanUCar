<div id =bottomBarMobile>
        <div id = "navigation">
            <div>
                <a href = "../../Paginas/Cuenta/userProfile.php">
                    <img src = "../../Imagenes/IconoUsuario.png">
                </a>
            </div>
            <div>
                <a href = "../../Paginas/MainLand/index.php">
                    <img src = "../../Imagenes/Gps_icono.png">
                </a>
            </div>
            <div>
                <a href = "../../Paginas/PagosRealizados/VerifyPago.php">
                    <img src = "../../Imagenes/IconoVerificarPago.png">
                </a>
            </div>
        </div>
    </div>