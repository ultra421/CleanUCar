<?php
header("Location: Paginas/MainLand/index.php");
exit();
?>